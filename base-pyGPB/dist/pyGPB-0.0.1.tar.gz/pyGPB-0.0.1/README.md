# pyGPB
Generalised Poisson Binomial distribution
